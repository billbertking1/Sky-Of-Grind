---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Matter Ball
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# Matter Balls

<ItemImage id="matter_ball" scale="4" />

A ball of generic matter, useful as ammunition for a <ItemLink id="matter_cannon" /> or for producing [paintballs](paintballs.md).

Made with 256 items or buckets in a <ItemLink id="condenser" /> in matter ball mode.
